import org.jsfml.graphics.RenderWindow;
import org.jsfml.window.event.Event;

public class ProgramEvents {
    public static Event peak(RenderWindow win) {
        Iterable<Event> events = win.pollEvents();
        for (Event event : events) {
            if (event.type == Event.Type.CLOSED) {
                win.close();

            }
            return event;
        }
        return null;
    }
}

public class Constants {

    static final String resourcesPackage =
        System.getProperty("user.dir") + "\\res";
    static final String fontsPackage =
            resourcesPackage + "\\fonts";

}

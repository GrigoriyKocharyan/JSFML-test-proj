import org.jsfml.graphics.*;

public class Theme {

    public Color standartColor;
    public Color hoverColor;
    public Color standartTextColor;
    public Color hoverTextColor;
    public Font font;
    public int textSize;

    public Theme(Color standartColor,
          Color hoverColor,
          Color standartTextColor,
          Color hoverTextColor,
          Font font,
          int textSize) {

        this.standartColor = standartColor;
        this.hoverColor = hoverColor;
        this.standartTextColor = standartTextColor;
        this.hoverTextColor = hoverTextColor;
        this.font = font;
        this.textSize = textSize;

    }

}

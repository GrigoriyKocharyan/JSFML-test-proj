
import org.jsfml.graphics.*;
import org.jsfml.window.Keyboard;
import org.jsfml.window.Mouse;
import org.jsfml.window.VideoMode;
import org.jsfml.window.event.*;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

public class Main {

    static VideoMode videoMode = new VideoMode(700, 400);
    static RenderWindow win;
    static String title = "JSFML Window";
    static Color bg = new Color(30, 30, 30);
    static Theme mainTheme;
    static Font mainFont;
    static Button button01;
    static Event currentEvent;
    static float mx, my;
    static String currentDir = "C://";
    static File dir;
    static float coordy = 1f;
    static View allFilesField;

    public static void main(String[] args) throws IOException {
        init();
    }

    public static void init() throws IOException {
        win = new RenderWindow(videoMode, title);
        mainFont = new Font();
        mainFont.loadFromFile(Paths.get(Constants.fontsPackage + "\\gotham_medium.otf"));
        mainTheme = new Theme(
                new Color(40, 40, 40),
                new Color(60, 60, 60),
                new Color(200, 200, 200),
                new Color(250, 250, 250),
                mainFont, 15
        );

        allFilesField = new View(new FloatRect(200, 50, 490, 340));


        button01 = new Button(win, "Hello", new Rect(20, 20, 200, 80),
                mainTheme);



        mainLoop();

    }

    public static void mainLoop() throws IOException {
        while (win.isOpen()) {
            eventPeak();
            update();
            win.clear(bg);
            render();
            win.display();
        }
    }

    public static void eventPeak() {
        currentEvent = ProgramEvents.peak(win);
    }

    public static void update() {

    }

    public static void render() throws IOException {



        dir = new File(currentDir); //path указывает на директорию

        List<File> files = new ArrayList<>();
        List<Button> buttons = new ArrayList<>();
        int index = 0;

        for (File file : dir.listFiles()) {

            buttons.add(new Button(win, file.getName(), new Rect(200, index * 20, 500, 20),
                mainTheme));



            buttons.get(index).listener = new ButtonListener() {

                @Override
                public void listener(Button button) throws IOException {

                    coordy = 0;

                    if (button.text.charAt(button.text.length() - 1) == 'i') {
                        Process process = new ProcessBuilder(currentDir + "\\" + button.text).start();
                    } else {
                        currentDir = currentDir + "\\" + button.text;
                    }
                }
            };

            if (file.isDirectory()) {
                buttons.get(index).theme.standartColor = new Color(30, 30, 30);
            }
            else {
                files.add(file);
            }
            index++;
        }

        for (Button button : buttons) {
            if (currentEvent != null) {
                if (currentEvent.type == Event.Type.MOUSE_WHEEL_MOVED) {
                    int delta = currentEvent.asMouseWheelEvent().delta;
                    coordy += delta;
                }
            }

            button.rect.y = button.rect.y + coordy;

            button.draw(currentEvent);
        }


    }

}

